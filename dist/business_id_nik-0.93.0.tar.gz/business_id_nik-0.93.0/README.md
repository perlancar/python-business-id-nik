# Parse Indonesian citizenship registration number (NIK)

More description to be written.
